
package Model;


public interface Sortable {
	public void sort(String task);
	public int getSortField();
	public void SetSortField(int sortField);
}
